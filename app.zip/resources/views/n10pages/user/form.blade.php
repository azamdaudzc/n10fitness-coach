

    <div class="py-5">
                <div class="rounded border p-10">
                         <div class="mb-10">
            {{ Form::label('first_name','', array('class' => 'form-label')) }}
            {{ Form::text('first_name', $user->first_name, ['class' => 'form-control' . ($errors->has('first_name') ? ' is-invalid' : ''), 'placeholder' => 'First Name']) }}
            {!! $errors->first('first_name', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('last_name','', array('class' => 'form-label')) }}
            {{ Form::text('last_name', $user->last_name, ['class' => 'form-control' . ($errors->has('last_name') ? ' is-invalid' : ''), 'placeholder' => 'Last Name']) }}
            {!! $errors->first('last_name', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('avatar','', array('class' => 'form-label')) }}
            {{ Form::text('avatar', $user->avatar, ['class' => 'form-control' . ($errors->has('avatar') ? ' is-invalid' : ''), 'placeholder' => 'Avatar']) }}
            {!! $errors->first('avatar', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('email','', array('class' => 'form-label')) }}
            {{ Form::text('email', $user->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email']) }}
            {!! $errors->first('email', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('phone','', array('class' => 'form-label')) }}
            {{ Form::text('phone', $user->phone, ['class' => 'form-control' . ($errors->has('phone') ? ' is-invalid' : ''), 'placeholder' => 'Phone']) }}
            {!! $errors->first('phone', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_type','', array('class' => 'form-label')) }}
            {{ Form::text('user_type', $user->user_type, ['class' => 'form-control' . ($errors->has('user_type') ? ' is-invalid' : ''), 'placeholder' => 'User Type']) }}
            {!! $errors->first('user_type', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('is_active','', array('class' => 'form-label')) }}
            {{ Form::text('is_active', $user->is_active, ['class' => 'form-control' . ($errors->has('is_active') ? ' is-invalid' : ''), 'placeholder' => 'Is Active']) }}
            {!! $errors->first('is_active', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('athletic_type','', array('class' => 'form-label')) }}
            {{ Form::text('athletic_type', $user->athletic_type, ['class' => 'form-control' . ($errors->has('athletic_type') ? ' is-invalid' : ''), 'placeholder' => 'Athletic Type']) }}
            {!! $errors->first('athletic_type', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('height','', array('class' => 'form-label')) }}
            {{ Form::text('height', $user->height, ['class' => 'form-control' . ($errors->has('height') ? ' is-invalid' : ''), 'placeholder' => 'Height']) }}
            {!! $errors->first('height', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('age','', array('class' => 'form-label')) }}
            {{ Form::text('age', $user->age, ['class' => 'form-control' . ($errors->has('age') ? ' is-invalid' : ''), 'placeholder' => 'Age']) }}
            {!! $errors->first('age', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('gender','', array('class' => 'form-label')) }}
            {{ Form::text('gender', $user->gender, ['class' => 'form-control' . ($errors->has('gender') ? ' is-invalid' : ''), 'placeholder' => 'Gender']) }}
            {!! $errors->first('gender', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_checkin','', array('class' => 'form-label')) }}
            {{ Form::text('user_checkin', $user->user_checkin, ['class' => 'form-control' . ($errors->has('user_checkin') ? ' is-invalid' : ''), 'placeholder' => 'User Checkin']) }}
            {!! $errors->first('user_checkin', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('change_password','', array('class' => 'form-label')) }}
            {{ Form::text('change_password', $user->change_password, ['class' => 'form-control' . ($errors->has('change_password') ? ' is-invalid' : ''), 'placeholder' => 'Change Password']) }}
            {!! $errors->first('change_password', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="error-area"></div>
                  <div class="box-footer mt20">
                    <button type="button" onclick="submitCreateForm()" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>

            <script>

     function submitCreateForm () {

      $.ajax({
         type:'POST',
         data: $('#createNewForm').serialize(),
         url:"{{ route('users.store') }}",
         headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
         success:function(data){
            location.reload();
         },
         error:function(data){
          var response = JSON.parse(data.responseText);
        var errorString = '<ul>';
        $.each( response.errors, function( key, value) {
            errorString += '<li>' + value + '</li>';
        });
        errorString += '</ul>';
        $('.error-area').html('')
        $('.error-area').append(errorString);
        // alert(errorString);
         }
      });
    }

</script>
