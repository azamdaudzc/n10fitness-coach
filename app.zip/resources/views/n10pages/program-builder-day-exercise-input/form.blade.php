

    <div class="py-5">
                <div class="rounded border p-10">
                    <div class="mb-10">
            {{ Form::label('day_exercise_id','', array('class' => 'form-label')) }}
            {{ Form::text('day_exercise_id', $programBuilderDayExerciseInput->day_exercise_id, ['class' => 'form-control' . ($errors->has('day_exercise_id') ? ' is-invalid' : ''), 'placeholder' => 'Day Exercise Id']) }}
            {!! $errors->first('day_exercise_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('program_builder_id','', array('class' => 'form-label')) }}
            {{ Form::text('program_builder_id', $programBuilderDayExerciseInput->program_builder_id, ['class' => 'form-control' . ($errors->has('program_builder_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Builder Id']) }}
            {!! $errors->first('program_builder_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('set_no','', array('class' => 'form-label')) }}
            {{ Form::text('set_no', $programBuilderDayExerciseInput->set_no, ['class' => 'form-control' . ($errors->has('set_no') ? ' is-invalid' : ''), 'placeholder' => 'Set No']) }}
            {!! $errors->first('set_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('weight','', array('class' => 'form-label')) }}
            {{ Form::text('weight', $programBuilderDayExerciseInput->weight, ['class' => 'form-control' . ($errors->has('weight') ? ' is-invalid' : ''), 'placeholder' => 'Weight']) }}
            {!! $errors->first('weight', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('reps','', array('class' => 'form-label')) }}
            {{ Form::text('reps', $programBuilderDayExerciseInput->reps, ['class' => 'form-control' . ($errors->has('reps') ? ' is-invalid' : ''), 'placeholder' => 'Reps']) }}
            {!! $errors->first('reps', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rpe','', array('class' => 'form-label')) }}
            {{ Form::text('rpe', $programBuilderDayExerciseInput->rpe, ['class' => 'form-control' . ($errors->has('rpe') ? ' is-invalid' : ''), 'placeholder' => 'Rpe']) }}
            {!! $errors->first('rpe', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('peak_exterted_max','', array('class' => 'form-label')) }}
            {{ Form::text('peak_exterted_max', $programBuilderDayExerciseInput->peak_exterted_max, ['class' => 'form-control' . ($errors->has('peak_exterted_max') ? ' is-invalid' : ''), 'placeholder' => 'Peak Exterted Max']) }}
            {!! $errors->first('peak_exterted_max', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>