@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderDayExerciseInput->name ?? 'Show Program Builder Day Exercise Input' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Day Exercise Input</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('builder-day-exercise-inputs.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">

                        <div class="form-group">
                            <strong>Day Exercise Id:</strong>
                            {{ $programBuilderDayExerciseInput->day_exercise_id }}
                        </div>
                        <div class="form-group">
                            <strong>Program Builder Id:</strong>
                            {{ $programBuilderDayExerciseInput->program_builder_id }}
                        </div>
                        <div class="form-group">
                            <strong>Set No:</strong>
                            {{ $programBuilderDayExerciseInput->set_no }}
                        </div>
                        <div class="form-group">
                            <strong>Weight:</strong>
                            {{ $programBuilderDayExerciseInput->weight }}
                        </div>
                        <div class="form-group">
                            <strong>Reps:</strong>
                            {{ $programBuilderDayExerciseInput->reps }}
                        </div>
                        <div class="form-group">
                            <strong>Rpe:</strong>
                            {{ $programBuilderDayExerciseInput->rpe }}
                        </div>
                        <div class="form-group">
                            <strong>Peak Exterted Max:</strong>
                            {{ $programBuilderDayExerciseInput->peak_exterted_max }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
