@extends('layouts.main-layout')

@section('template_title')
    Update User Checkin
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title">Update User Checkin</span>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('user-checkins.update', $userCheckin->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('n10pages.user-checkin.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
