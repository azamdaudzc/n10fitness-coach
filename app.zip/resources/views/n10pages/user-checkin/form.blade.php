

    <div class="py-5">
                <div class="rounded border p-10">
                     <div class="mb-10">
            {{ Form::label('checkin_time','', array('class' => 'form-label')) }}
            {{ Form::text('checkin_time', $userCheckin->checkin_time, ['class' => 'form-control' . ($errors->has('checkin_time') ? ' is-invalid' : ''), 'placeholder' => 'Checkin Time']) }}
            {!! $errors->first('checkin_time', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_id','', array('class' => 'form-label')) }}
            {{ Form::text('user_id', $userCheckin->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id']) }}
            {!! $errors->first('user_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>