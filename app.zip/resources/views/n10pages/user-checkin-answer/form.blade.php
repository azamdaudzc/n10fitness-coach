
    <div class="py-5">
                <div class="rounded border p-10">
                           <div class="mb-10">
            {{ Form::label('answer','', array('class' => 'form-label')) }}
            {{ Form::text('answer', $userCheckinAnswer->answer, ['class' => 'form-control' . ($errors->has('answer') ? ' is-invalid' : ''), 'placeholder' => 'Answer']) }}
            {!! $errors->first('answer', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_checkin_id','', array('class' => 'form-label')) }}
            {{ Form::text('user_checkin_id', $userCheckinAnswer->user_checkin_id, ['class' => 'form-control' . ($errors->has('user_checkin_id') ? ' is-invalid' : ''), 'placeholder' => 'User Checkin Id']) }}
            {!! $errors->first('user_checkin_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('checkin_question_input_id','', array('class' => 'form-label')) }}
            {{ Form::text('checkin_question_input_id', $userCheckinAnswer->checkin_question_input_id, ['class' => 'form-control' . ($errors->has('checkin_question_input_id') ? ' is-invalid' : ''), 'placeholder' => 'Checkin Question Input Id']) }}
            {!! $errors->first('checkin_question_input_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('checkin_question_id','', array('class' => 'form-label')) }}
            {{ Form::text('checkin_question_id', $userCheckinAnswer->checkin_question_id, ['class' => 'form-control' . ($errors->has('checkin_question_id') ? ' is-invalid' : ''), 'placeholder' => 'Checkin Question Id']) }}
            {!! $errors->first('checkin_question_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>

                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>