@extends('layouts.main-layout')

@section('template_title')
    {{ $userCheckinAnswer->name ?? 'Show User Checkin Answer' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show User Checkin Answer</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('user-checkin-answers.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Answer:</strong>
                            {{ $userCheckinAnswer->answer }}
                        </div>
                        <div class="form-group">
                            <strong>User Checkin Id:</strong>
                            {{ $userCheckinAnswer->user_checkin_id }}
                        </div>
                        <div class="form-group">
                            <strong>Checkin Question Input Id:</strong>
                            {{ $userCheckinAnswer->checkin_question_input_id }}
                        </div>
                        <div class="form-group">
                            <strong>Checkin Question Id:</strong>
                            {{ $userCheckinAnswer->checkin_question_id }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
