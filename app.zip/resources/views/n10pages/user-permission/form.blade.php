

    <div class="py-5">
                <div class="rounded border p-10">
                     <div class="mb-10">
            {{ Form::label('name','', array('class' => 'form-label')) }}
            {{ Form::text('name', $userPermission->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name']) }}
            {!! $errors->first('name', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_id','', array('class' => 'form-label')) }}
            {{ Form::text('user_id', $userPermission->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id']) }}
            {!! $errors->first('user_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>

                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>