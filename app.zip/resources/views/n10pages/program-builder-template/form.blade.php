


    <div class="py-5">
                <div class="rounded border p-10">
                           <div class="mb-10">
            {{ Form::label('program_builder_id','', array('class' => 'form-label')) }}
            {{ Form::text('program_builder_id', $programBuilderTemplate->program_builder_id, ['class' => 'form-control' . ($errors->has('program_builder_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Builder Id']) }}
            {!! $errors->first('program_builder_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('is_approved','', array('class' => 'form-label')) }}
            {{ Form::text('is_approved', $programBuilderTemplate->is_approved, ['class' => 'form-control' . ($errors->has('is_approved') ? ' is-invalid' : ''), 'placeholder' => 'Is Approved']) }}
            {!! $errors->first('is_approved', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('created_by','', array('class' => 'form-label')) }}
            {{ Form::text('created_by', $programBuilderTemplate->created_by, ['class' => 'form-control' . ($errors->has('created_by') ? ' is-invalid' : ''), 'placeholder' => 'Created By']) }}
            {!! $errors->first('created_by', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>