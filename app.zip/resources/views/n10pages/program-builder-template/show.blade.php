@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderTemplate->name ?? 'Show Program Builder Template' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Template</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('program-builder-templates.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Program Builder Id:</strong>
                            {{ $programBuilderTemplate->program_builder_id }}
                        </div>
                        <div class="form-group">
                            <strong>Is Approved:</strong>
                            {{ $programBuilderTemplate->is_approved }}
                        </div>
                        <div class="form-group">
                            <strong>Created By:</strong>
                            {{ $programBuilderTemplate->created_by }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
