
    <div class="py-5">
                <div class="rounded border p-10">
                   <div class="mb-10">
                {{ Form::label('name', 'Coach Id', array('class' => 'form-label')) }}
            {{ Form::text('coach_id', $clientCoach->coach_id, ['class' => 'form-control' . ($errors->has('coach_id') ? ' is-invalid' : ''), 'placeholder' => 'Coach Id']) }}
            {!! $errors->first('coach_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
               {{ Form::label('name', 'Assigned By', array('class' => 'form-label')) }}
            {{ Form::text('assigned_by', $clientCoach->assigned_by, ['class' => 'form-control' . ($errors->has('assigned_by') ? ' is-invalid' : ''), 'placeholder' => 'Assigned By']) }}
            {!! $errors->first('assigned_by', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
                {{ Form::label('name', 'Client Id', array('class' => 'form-label')) }}
            {{ Form::text('client_id', $clientCoach->client_id, ['class' => 'form-control' . ($errors->has('client_id') ? ' is-invalid' : ''), 'placeholder' => 'Client Id']) }}
            {!! $errors->first('client_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>