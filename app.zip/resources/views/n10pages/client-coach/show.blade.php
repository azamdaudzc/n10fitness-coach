@extends('layouts.main-layout')

@section('template_title')
    {{ $clientCoach->name ?? 'Show Client Coach' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Client Coach</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('client-coaches.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Coach Id:</strong>
                            {{ $clientCoach->coach_id }}
                        </div>
                        <div class="form-group">
                            <strong>Assigned By:</strong>
                            {{ $clientCoach->assigned_by }}
                        </div>
                        <div class="form-group">
                            <strong>Client Id:</strong>
                            {{ $clientCoach->client_id }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
