


    <div class="py-5">
                <div class="rounded border p-10">
                    <div class="mb-10">
            {{ Form::label('title','', array('class' => 'form-label')) }}
            {{ Form::text('title', $programBuilder->title, ['class' => 'form-control' . ($errors->has('title') ? ' is-invalid' : ''), 'placeholder' => 'Title']) }}
            {!! $errors->first('title', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_id','', array('class' => 'form-label')) }}
            {{ Form::text('user_id', $programBuilder->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id']) }}
            {!! $errors->first('user_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('days','', array('class' => 'form-label')) }}
            {{ Form::text('days', $programBuilder->days, ['class' => 'form-control' . ($errors->has('days') ? ' is-invalid' : ''), 'placeholder' => 'Days']) }}
            {!! $errors->first('days', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('weeks','', array('class' => 'form-label')) }}
            {{ Form::text('weeks', $programBuilder->weeks, ['class' => 'form-control' . ($errors->has('weeks') ? ' is-invalid' : ''), 'placeholder' => 'Weeks']) }}
            {!! $errors->first('weeks', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('is_finished','', array('class' => 'form-label')) }}
            {{ Form::text('is_finished', $programBuilder->is_finished, ['class' => 'form-control' . ($errors->has('is_finished') ? ' is-invalid' : ''), 'placeholder' => 'Is Finished']) }}
            {!! $errors->first('is_finished', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('created_by','', array('class' => 'form-label')) }}
            {{ Form::text('created_by', $programBuilder->created_by, ['class' => 'form-control' . ($errors->has('created_by') ? ' is-invalid' : ''), 'placeholder' => 'Created By']) }}
            {!! $errors->first('created_by', '<div class="invalid-feedback">:message</div>') !!}
        </div>

                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>  