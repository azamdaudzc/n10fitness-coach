@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilder->name ?? 'Show Program Builder' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('program-builders.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Title:</strong>
                            {{ $programBuilder->title }}
                        </div>
                        <div class="form-group">
                            <strong>User Id:</strong>
                            {{ $programBuilder->user_id }}
                        </div>
                        <div class="form-group">
                            <strong>Days:</strong>
                            {{ $programBuilder->days }}
                        </div>
                        <div class="form-group">
                            <strong>Weeks:</strong>
                            {{ $programBuilder->weeks }}
                        </div>
                        <div class="form-group">
                            <strong>Is Finished:</strong>
                            {{ $programBuilder->is_finished }}
                        </div>
                        <div class="form-group">
                            <strong>Created By:</strong>
                            {{ $programBuilder->created_by }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
