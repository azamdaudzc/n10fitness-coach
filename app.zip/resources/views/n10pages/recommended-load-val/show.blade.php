@extends('layouts.main-layout')

@section('template_title')
    {{ $recommendedLoadVal->name ?? 'Show Recommended Load Val' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Recommended Load Val</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('recommended-load-vals.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Reps:</strong>
                            {{ $recommendedLoadVal->reps }}
                        </div>
                        <div class="form-group">
                            <strong>Rpe:</strong>
                            {{ $recommendedLoadVal->rpe }}
                        </div>
                        <div class="form-group">
                            <strong>Val:</strong>
                            {{ $recommendedLoadVal->val }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
