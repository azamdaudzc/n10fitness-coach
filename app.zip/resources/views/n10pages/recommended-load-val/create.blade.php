@extends('layouts.main-layout')

@section('template_title')
    Create Recommended Load Val
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title">Create Recommended Load Val</span>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('recommended-load-vals.store') }}"  role="form" enctype="multipart/form-data">
                            @csrf

                            @include('n10pages.recommended-load-val.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
