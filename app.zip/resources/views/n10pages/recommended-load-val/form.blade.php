

    <div class="py-5">
                <div class="rounded border p-10">
                           <div class="mb-10">
            {{ Form::label('reps','', array('class' => 'form-label')) }}
            {{ Form::text('reps', $recommendedLoadVal->reps, ['class' => 'form-control' . ($errors->has('reps') ? ' is-invalid' : ''), 'placeholder' => 'Reps']) }}
            {!! $errors->first('reps', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rpe','', array('class' => 'form-label')) }}
            {{ Form::text('rpe', $recommendedLoadVal->rpe, ['class' => 'form-control' . ($errors->has('rpe') ? ' is-invalid' : ''), 'placeholder' => 'Rpe']) }}
            {!! $errors->first('rpe', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('val','', array('class' => 'form-label')) }}
            {{ Form::text('val', $recommendedLoadVal->val, ['class' => 'form-control' . ($errors->has('val') ? ' is-invalid' : ''), 'placeholder' => 'Val']) }}
            {!! $errors->first('val', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>