@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderWeek->name ?? 'Show Program Builder Week' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Week</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('program-builder-weeks.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Program Builder Id:</strong>
                            {{ $programBuilderWeek->program_builder_id }}
                        </div>
                        <div class="form-group">
                            <strong>Week No:</strong>
                            {{ $programBuilderWeek->week_no }}
                        </div>
                        <div class="form-group">
                            <strong>Assigned Calories:</strong>
                            {{ $programBuilderWeek->assigned_calories }}
                        </div>
                        <div class="form-group">
                            <strong>Assigned Proteins:</strong>
                            {{ $programBuilderWeek->assigned_proteins }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
