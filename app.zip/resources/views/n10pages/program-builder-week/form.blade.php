

    <div class="py-5">
                <div class="rounded border p-10">
                          <div class="mb-10">
            {{ Form::label('program_builder_id','', array('class' => 'form-label')) }}
            {{ Form::text('program_builder_id', $programBuilderWeek->program_builder_id, ['class' => 'form-control' . ($errors->has('program_builder_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Builder Id']) }}
            {!! $errors->first('program_builder_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('week_no','', array('class' => 'form-label')) }}
            {{ Form::text('week_no', $programBuilderWeek->week_no, ['class' => 'form-control' . ($errors->has('week_no') ? ' is-invalid' : ''), 'placeholder' => 'Week No']) }}
            {!! $errors->first('week_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('assigned_calories','', array('class' => 'form-label')) }}
            {{ Form::text('assigned_calories', $programBuilderWeek->assigned_calories, ['class' => 'form-control' . ($errors->has('assigned_calories') ? ' is-invalid' : ''), 'placeholder' => 'Assigned Calories']) }}
            {!! $errors->first('assigned_calories', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('assigned_proteins','', array('class' => 'form-label')) }}
            {{ Form::text('assigned_proteins', $programBuilderWeek->assigned_proteins, ['class' => 'form-control' . ($errors->has('assigned_proteins') ? ' is-invalid' : ''), 'placeholder' => 'Assigned Proteins']) }}
            {!! $errors->first('assigned_proteins', '<div class="invalid-feedback">:message</div>') !!}
        </div>

                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>