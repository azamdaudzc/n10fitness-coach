
    <div class="py-5">
                <div class="rounded border p-10">
                    <div class="mb-10">
            {{ Form::label('builder_week_day_id','', array('class' => 'form-label')) }}
            {{ Form::text('builder_week_day_id', $programBuilderDayExercise->builder_week_day_id, ['class' => 'form-control' . ($errors->has('builder_week_day_id') ? ' is-invalid' : ''), 'placeholder' => 'Builder Week Day Id']) }}
            {!! $errors->first('builder_week_day_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('exercise_library_id','', array('class' => 'form-label')) }}
            {{ Form::text('exercise_library_id', $programBuilderDayExercise->exercise_library_id, ['class' => 'form-control' . ($errors->has('exercise_library_id') ? ' is-invalid' : ''), 'placeholder' => 'Exercise Library Id']) }}
            {!! $errors->first('exercise_library_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('sets_no','', array('class' => 'form-label')) }}
            {{ Form::text('sets_no', $programBuilderDayExercise->sets_no, ['class' => 'form-control' . ($errors->has('sets_no') ? ' is-invalid' : ''), 'placeholder' => 'Sets No']) }}
            {!! $errors->first('sets_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rep_min_no','', array('class' => 'form-label')) }}
            {{ Form::text('rep_min_no', $programBuilderDayExercise->rep_min_no, ['class' => 'form-control' . ($errors->has('rep_min_no') ? ' is-invalid' : ''), 'placeholder' => 'Rep Min No']) }}
            {!! $errors->first('rep_min_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rep_max_no','', array('class' => 'form-label')) }}
            {{ Form::text('rep_max_no', $programBuilderDayExercise->rep_max_no, ['class' => 'form-control' . ($errors->has('rep_max_no') ? ' is-invalid' : ''), 'placeholder' => 'Rep Max No']) }}
            {!! $errors->first('rep_max_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rpe_no','', array('class' => 'form-label')) }}
            {{ Form::text('rpe_no', $programBuilderDayExercise->rpe_no, ['class' => 'form-control' . ($errors->has('rpe_no') ? ' is-invalid' : ''), 'placeholder' => 'Rpe No']) }}
            {!! $errors->first('rpe_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('load_text','', array('class' => 'form-label')) }}
            {{ Form::text('load_text', $programBuilderDayExercise->load_text, ['class' => 'form-control' . ($errors->has('load_text') ? ' is-invalid' : ''), 'placeholder' => 'Load Text']) }}
            {!! $errors->first('load_text', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rest_time','', array('class' => 'form-label')) }}
            {{ Form::text('rest_time', $programBuilderDayExercise->rest_time, ['class' => 'form-control' . ($errors->has('rest_time') ? ' is-invalid' : ''), 'placeholder' => 'Rest Time']) }}
            {!! $errors->first('rest_time', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('notes','', array('class' => 'form-label')) }}
            {{ Form::text('notes', $programBuilderDayExercise->notes, ['class' => 'form-control' . ($errors->has('notes') ? ' is-invalid' : ''), 'placeholder' => 'Notes']) }}
            {!! $errors->first('notes', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>