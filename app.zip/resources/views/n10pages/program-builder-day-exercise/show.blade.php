@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderDayExercise->name ?? 'Show Program Builder Day Exercise' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Day Exercise</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('program-builders-day-exercises.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">

                        <div class="form-group">
                            <strong>Builder Week Day Id:</strong>
                            {{ $programBuilderDayExercise->builder_week_day_id }}
                        </div>
                        <div class="form-group">
                            <strong>Exercise Library Id:</strong>
                            {{ $programBuilderDayExercise->exercise_library_id }}
                        </div>
                        <div class="form-group">
                            <strong>Sets No:</strong>
                            {{ $programBuilderDayExercise->sets_no }}
                        </div>
                        <div class="form-group">
                            <strong>Rep Min No:</strong>
                            {{ $programBuilderDayExercise->rep_min_no }}
                        </div>
                        <div class="form-group">
                            <strong>Rep Max No:</strong>
                            {{ $programBuilderDayExercise->rep_max_no }}
                        </div>
                        <div class="form-group">
                            <strong>Rpe No:</strong>
                            {{ $programBuilderDayExercise->rpe_no }}
                        </div>
                        <div class="form-group">
                            <strong>Load Text:</strong>
                            {{ $programBuilderDayExercise->load_text }}
                        </div>
                        <div class="form-group">
                            <strong>Rest Time:</strong>
                            {{ $programBuilderDayExercise->rest_time }}
                        </div>
                        <div class="form-group">
                            <strong>Notes:</strong>
                            {{ $programBuilderDayExercise->notes }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
