@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderShare->name ?? 'Show Program Builder Share' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Share</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('program-builder-shares.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Program Builder Id:</strong>
                            {{ $programBuilderShare->program_builder_id }}
                        </div>
                        <div class="form-group">
                            <strong>User Id:</strong>
                            {{ $programBuilderShare->user_id }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
