

    <div class="py-5">
                <div class="rounded border p-10">
                         <div class="mb-10">
            {{ Form::label('program_builder_id','', array('class' => 'form-label')) }}
            {{ Form::text('program_builder_id', $programBuilderShare->program_builder_id, ['class' => 'form-control' . ($errors->has('program_builder_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Builder Id']) }}
            {!! $errors->first('program_builder_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('user_id','', array('class' => 'form-label')) }}
            {{ Form::text('user_id', $programBuilderShare->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id']) }}
            {!! $errors->first('user_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>