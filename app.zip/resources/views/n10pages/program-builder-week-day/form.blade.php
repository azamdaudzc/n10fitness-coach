

    <div class="py-5">
                <div class="rounded border p-10">
                    <div class="mb-10">
            {{ Form::label('program_builder_week_id','', array('class' => 'form-label')) }}
            {{ Form::text('program_builder_week_id', $programBuilderWeekDay->program_builder_week_id, ['class' => 'form-control' . ($errors->has('program_builder_week_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Builder Week Id']) }}
            {!! $errors->first('program_builder_week_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('day_title','', array('class' => 'form-label')) }}
            {{ Form::text('day_title', $programBuilderWeekDay->day_title, ['class' => 'form-control' . ($errors->has('day_title') ? ' is-invalid' : ''), 'placeholder' => 'Day Title']) }}
            {!! $errors->first('day_title', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('day_no','', array('class' => 'form-label')) }}
            {{ Form::text('day_no', $programBuilderWeekDay->day_no, ['class' => 'form-control' . ($errors->has('day_no') ? ' is-invalid' : ''), 'placeholder' => 'Day No']) }}
            {!! $errors->first('day_no', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>