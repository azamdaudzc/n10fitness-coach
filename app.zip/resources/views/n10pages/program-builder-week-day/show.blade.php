@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderWeekDay->name ?? 'Show Program Builder Week Day' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Week Day</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('program-builder-week-days.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Program Builder Week Id:</strong>
                            {{ $programBuilderWeekDay->program_builder_week_id }}
                        </div>
                        <div class="form-group">
                            <strong>Day Title:</strong>
                            {{ $programBuilderWeekDay->day_title }}
                        </div>
                        <div class="form-group">
                            <strong>Day No:</strong>
                            {{ $programBuilderWeekDay->day_no }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
