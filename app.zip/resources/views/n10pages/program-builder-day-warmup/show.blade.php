@extends('layouts.main-layout')

@section('template_title')
    {{ $programBuilderDayWarmup->name ?? 'Show Program Builder Day Warmup' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Program Builder Day Warmup</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('builder-day-warmups.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Program Builder Week Day Id:</strong>
                            {{ $programBuilderDayWarmup->program_builder_week_day_id }}
                        </div>
                        <div class="form-group">
                            <strong>Warmup Builder Id:</strong>
                            {{ $programBuilderDayWarmup->warmup_builder_id }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
