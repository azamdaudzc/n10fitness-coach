

    <div class="py-5">
                <div class="rounded border p-10">
                           <div class="mb-10">
            {{ Form::label('program_builder_week_day_id','', array('class' => 'form-label')) }}
            {{ Form::text('program_builder_week_day_id', $programBuilderDayWarmup->program_builder_week_day_id, ['class' => 'form-control' . ($errors->has('program_builder_week_day_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Builder Week Day Id']) }}
            {!! $errors->first('program_builder_week_day_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('warmup_builder_id','', array('class' => 'form-label')) }}
            {{ Form::text('warmup_builder_id', $programBuilderDayWarmup->warmup_builder_id, ['class' => 'form-control' . ($errors->has('warmup_builder_id') ? ' is-invalid' : ''), 'placeholder' => 'Warmup Builder Id']) }}
            {!! $errors->first('warmup_builder_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>