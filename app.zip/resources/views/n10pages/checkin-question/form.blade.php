

<div class="py-5">
    <div class="rounded border p-10">
        <div class="mb-10">
         
           {{ Form::label('Question', 'Question', array('class' => 'form-label')) }}
           {{ Form::text('question', $checkinQuestion->question, ['class' => 'form-control' . ($errors->has('question') ? ' is-invalid' : ''), 'placeholder' => 'Question']) }}
           {!! $errors->first('question', '<div class="invalid-feedback">:message</div>') !!}
       </div>

       <div class="mb-10">
        
        {{ Form::label('display_order', 'Display Order', array('class' => 'form-label')) }}
        {{ Form::text('display_order', $checkinQuestion->display_order, ['class' => 'form-control' . ($errors->has('display_order') ? ' is-invalid' : ''), 'placeholder' => 'Display Order']) }}
        {!! $errors->first('display_order', '<div class="invalid-feedback">:message</div>') !!}
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>

</div>