@extends('layouts.main-layout')

@section('template_title')
    {{ $checkinQuestion->name ?? 'Show Checkin Question' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Checkin Question</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('checkin-questions.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Question:</strong>
                            {{ $checkinQuestion->question }}
                        </div>
                        <div class="form-group">
                            <strong>Display Order:</strong>
                            {{ $checkinQuestion->display_order }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
