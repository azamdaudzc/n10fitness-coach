@extends('layouts.main-layout')

@section('template_title')
    {{ $checkinQuestionInput->name ?? 'Show Checkin Question Input' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Checkin Question Input</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('checkin-question-inputs.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Input Type:</strong>
                            {{ $checkinQuestionInput->input_type }}
                        </div>
                        <div class="form-group">
                            <strong>Label:</strong>
                            {{ $checkinQuestionInput->label }}
                        </div>
                        <div class="form-group">
                            <strong>Placeholder:</strong>
                            {{ $checkinQuestionInput->placeholder }}
                        </div>
                        <div class="form-group">
                            <strong>Is Required:</strong>
                            {{ $checkinQuestionInput->is_required }}
                        </div>
                        <div class="form-group">
                            <strong>Display Order:</strong>
                            {{ $checkinQuestionInput->display_order }}
                        </div>
                        <div class="form-group">
                            <strong>Checkin Question Id:</strong>
                            {{ $checkinQuestionInput->checkin_question_id }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
