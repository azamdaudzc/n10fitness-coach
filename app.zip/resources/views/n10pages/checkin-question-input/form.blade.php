

    <div class="py-5">
                <div class="rounded border p-10">
                     <div class="mb-10">
           {{ Form::label('name', 'Input Type', array('class' => 'form-label')) }}
            {{ Form::text('input_type', $checkinQuestionInput->input_type, ['class' => 'form-control' . ($errors->has('input_type') ? ' is-invalid' : ''), 'placeholder' => 'Input Type']) }}
            {!! $errors->first('input_type', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
           {{ Form::label('name', 'Label', array('class' => 'form-label')) }}
            {{ Form::text('label', $checkinQuestionInput->label, ['class' => 'form-control' . ($errors->has('label') ? ' is-invalid' : ''), 'placeholder' => 'Label']) }}
            {!! $errors->first('label', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('name', 'Placeholder', array('class' => 'form-label')) }}
            {{ Form::text('placeholder', $checkinQuestionInput->placeholder, ['class' => 'form-control' . ($errors->has('placeholder') ? ' is-invalid' : ''), 'placeholder' => 'Placeholder']) }}
            {!! $errors->first('placeholder', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
           {{ Form::label('name', 'Is Required', array('class' => 'form-label')) }}
            {{ Form::text('is_required', $checkinQuestionInput->is_required, ['class' => 'form-control' . ($errors->has('is_required') ? ' is-invalid' : ''), 'placeholder' => 'Is Required']) }}
            {!! $errors->first('is_required', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
           {{ Form::label('name', 'Display Order', array('class' => 'form-label')) }}
            {{ Form::text('display_order', $checkinQuestionInput->display_order, ['class' => 'form-control' . ($errors->has('display_order') ? ' is-invalid' : ''), 'placeholder' => 'Display Order']) }}
            {!! $errors->first('display_order', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('name', 'Checkin Question Id', array('class' => 'form-label')) }}
            {{ Form::text('checkin_question_id', $checkinQuestionInput->checkin_question_id, ['class' => 'form-control' . ($errors->has('checkin_question_id') ? ' is-invalid' : ''), 'placeholder' => 'Checkin Question Id']) }}
            {!! $errors->first('checkin_question_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>