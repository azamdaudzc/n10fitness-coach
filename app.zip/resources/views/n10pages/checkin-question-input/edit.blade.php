@extends('layouts.main-layout')

@section('template_title')
    Update Checkin Question Input
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title">Update Checkin Question Input</span>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('checkin-question-inputs.update', $checkinQuestionInput->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('n10pages.checkin-question-input.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
