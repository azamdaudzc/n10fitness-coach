@extends('layouts.main-layout')

@section('template_title')
    {{ $warmupVideo->name ?? 'Show Warmup Video' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Warmup Video</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('warmup-videos.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Video Url:</strong>
                            {{ $warmupVideo->video_url }}
                        </div>
                        <div class="form-group">
                            <strong>Thumbnail:</strong>
                            {{ $warmupVideo->thumbnail }}
                        </div>
                        <div class="form-group">
                            <strong>Warmup Builder Id:</strong>
                            {{ $warmupVideo->warmup_builder_id }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
