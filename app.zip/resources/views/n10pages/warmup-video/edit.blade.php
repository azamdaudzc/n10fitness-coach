@extends('layouts.main-layout')

@section('template_title')
    Update Warmup Video
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title">Update Warmup Video</span>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('warmup-videos.update', $warmupVideo->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf

                            @include('n10pages.warmup-video.form')

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection
