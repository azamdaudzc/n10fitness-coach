

    <div class="py-5">
                <div class="rounded border p-10">
                      <div class="mb-10">
            {{ Form::label('video_url','', array('class' => 'form-label')) }}
            {{ Form::text('video_url', $warmupVideo->video_url, ['class' => 'form-control' . ($errors->has('video_url') ? ' is-invalid' : ''), 'placeholder' => 'Video Url']) }}
            {!! $errors->first('video_url', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('thumbnail','', array('class' => 'form-label')) }}
            {{ Form::text('thumbnail', $warmupVideo->thumbnail, ['class' => 'form-control' . ($errors->has('thumbnail') ? ' is-invalid' : ''), 'placeholder' => 'Thumbnail']) }}
            {!! $errors->first('thumbnail', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('warmup_builder_id','', array('class' => 'form-label')) }}
            {{ Form::text('warmup_builder_id', $warmupVideo->warmup_builder_id, ['class' => 'form-control' . ($errors->has('warmup_builder_id') ? ' is-invalid' : ''), 'placeholder' => 'Warmup Builder Id']) }}
            {!! $errors->first('warmup_builder_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>