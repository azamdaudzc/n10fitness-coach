
    <div class="py-5">
                <div class="rounded border p-10">
                            <div class="mb-10">
            {{ Form::label('name','', array('class' => 'form-label')) }}
            {{ Form::text('name', $warmupBuilder->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name']) }}
            {!! $errors->first('name', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('description','', array('class' => 'form-label')) }}
            {{ Form::text('description', $warmupBuilder->description, ['class' => 'form-control' . ($errors->has('description') ? ' is-invalid' : ''), 'placeholder' => 'Description']) }}
            {!! $errors->first('description', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('instructions','', array('class' => 'form-label')) }}
            {{ Form::text('instructions', $warmupBuilder->instructions, ['class' => 'form-control' . ($errors->has('instructions') ? ' is-invalid' : ''), 'placeholder' => 'Instructions']) }}
            {!! $errors->first('instructions', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('created_by','', array('class' => 'form-label')) }}
            {{ Form::text('created_by', $warmupBuilder->created_by, ['class' => 'form-control' . ($errors->has('created_by') ? ' is-invalid' : ''), 'placeholder' => 'Created By']) }}
            {!! $errors->first('created_by', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('rejected_by','', array('class' => 'form-label')) }}
            {{ Form::text('rejected_by', $warmupBuilder->rejected_by, ['class' => 'form-control' . ($errors->has('rejected_by') ? ' is-invalid' : ''), 'placeholder' => 'Rejected By']) }}
            {!! $errors->first('rejected_by', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="mb-10">
            {{ Form::label('approved_by','', array('class' => 'form-label')) }}
            {{ Form::text('approved_by', $warmupBuilder->approved_by, ['class' => 'form-control' . ($errors->has('approved_by') ? ' is-invalid' : ''), 'placeholder' => 'Approved By']) }}
            {!! $errors->first('approved_by', '<div class="invalid-feedback">:message</div>') !!}
        </div>
                  <div class="box-footer mt20">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </div>

            </div>