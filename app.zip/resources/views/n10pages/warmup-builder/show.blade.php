@extends('layouts.main-layout')

@section('template_title')
    {{ $warmupBuilder->name ?? 'Show Warmup Builder' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Warmup Builder</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('warmup-builders.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Name:</strong>
                            {{ $warmupBuilder->name }}
                        </div>
                        <div class="form-group">
                            <strong>Description:</strong>
                            {{ $warmupBuilder->description }}
                        </div>
                        <div class="form-group">
                            <strong>Instructions:</strong>
                            {{ $warmupBuilder->instructions }}
                        </div>
                        <div class="form-group">
                            <strong>Created By:</strong>
                            {{ $warmupBuilder->created_by }}
                        </div>
                        <div class="form-group">
                            <strong>Rejected By:</strong>
                            {{ $warmupBuilder->rejected_by }}
                        </div>
                        <div class="form-group">
                            <strong>Approved By:</strong>
                            {{ $warmupBuilder->approved_by }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
	@endsection