<?php

namespace App\Http\Controllers\N10Controllers;

use Illuminate\Http\Request;
use App\Models\ExerciseLibrary;
use App\Models\ExerciseCategory;
use App\Models\ExerciseEquipment;
use Illuminate\Support\Facades\Auth;
use App\Models\ExerciseMovementPattern;
/**
 * Class ExerciseLibraryController
 * @package App\Http\Controllers
 */
class ExerciseLibraryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $exerciseLibraries = ExerciseLibrary::paginate();
        $page_heading='Libraries';
        $sub_page_heading='exercise libraries';
        // return view('n10pages.exercise-library.index', compact('exerciseLibraries'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseLibraries->perPage());
        $exerciseLibraries = ExerciseLibrary::with('exerciseCategory','exerciseEquipment','exerciseMovementPattern')->where('created_by','=',Auth::user()->id)->get();
        $exerciseLibrary = new ExerciseLibrary();
        $categories=ExerciseCategory::all();
        $equipments=ExerciseEquipment::all();
        $movement_patterns=ExerciseMovementPattern::all();
        $formRoute=route('exercise-libraries.store');
        $type='POST';

        return view('n10pages.exercise-library.index', compact('exerciseLibrary','movement_patterns','categories','equipments','exerciseLibraries','formRoute','type','page_heading','sub_page_heading'));
    }



    public function indexApproved()
    {
        // $exerciseLibraries = ExerciseLibrary::paginate();
        $page_heading='Libraries';
        $sub_page_heading='approved exercise libraries';
        // return view('n10pages.exercise-library.index', compact('exerciseLibraries'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseLibraries->perPage());
        $exerciseLibraries = ExerciseLibrary::with('exerciseCategory','exerciseEquipment','exerciseMovementPattern')->where('approved_by','<>',0)->get();
        $exerciseLibrary = new ExerciseLibrary();
        $categories=ExerciseCategory::all();
        $equipments=ExerciseEquipment::all();
        $movement_patterns=ExerciseMovementPattern::all();
        $formRoute=route('exercise-libraries.store');
        $type='POST';

        return view('n10pages.exercise-library.index', compact('exerciseLibrary','movement_patterns','categories','equipments','exerciseLibraries','formRoute','type','page_heading','sub_page_heading'));
    }

    public function indexRequested()
    {
        // $exerciseLibraries = ExerciseLibrary::paginate();
        $page_heading='Libraries';
        $sub_page_heading='requested exercise libraries';
        // return view('n10pages.exercise-library.index', compact('exerciseLibraries'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseLibraries->perPage());
        $exerciseLibraries = ExerciseLibrary::with('exerciseCategory','exerciseEquipment','exerciseMovementPattern')->where('approved_by',0)->where('rejected_by',0)->get();
        $exerciseLibrary = new ExerciseLibrary();
        $categories=ExerciseCategory::all();
        $equipments=ExerciseEquipment::all();
        $movement_patterns=ExerciseMovementPattern::all();
        $formRoute=route('exercise-libraries.store');
        $type='POST';

        return view('n10pages.exercise-library.index', compact('exerciseLibrary','movement_patterns','categories','equipments','exerciseLibraries','formRoute','type','page_heading','sub_page_heading'));
    }

    public function indexRejected()
    {
        // $exerciseLibraries = ExerciseLibrary::paginate();
        $page_heading='Libraries';
        $sub_page_heading='rejected exercise libraries';
        // return view('n10pages.exercise-library.index', compact('exerciseLibraries'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseLibraries->perPage());
        $exerciseLibraries = ExerciseLibrary::with('exerciseCategory','exerciseEquipment','exerciseMovementPattern')->where('rejected_by','<>',0)->get();
        $exerciseLibrary = new ExerciseLibrary();
        $categories=ExerciseCategory::all();
        $equipments=ExerciseEquipment::all();
        $movement_patterns=ExerciseMovementPattern::all();
        $formRoute=route('exercise-libraries.store');
        $type='POST';

        return view('n10pages.exercise-library.index', compact('exerciseLibrary','movement_patterns','categories','equipments','exerciseLibraries','formRoute','type','page_heading','sub_page_heading'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $page_heading='Create Library';
        $sub_page_heading='create library';
        $exerciseLibrary = new ExerciseLibrary();
        $categories=ExerciseCategory::all();
        $equipments=ExerciseEquipment::all();
        $movement_patterns=ExerciseMovementPattern::all();
        return view('n10pages.exercise-library.create', compact('exerciseLibrary','movement_patterns','categories','equipments','page_heading','sub_page_heading'));
    }

    public function updateprofile(Request $request,$file)
    {
        $p = $request->input();
        $path ='';

        if ($request->file($file)) {
            $request->validate([
                $file => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);
            $imagePath = $request->file($file);
            $imageName = $imagePath->getClientOriginalName();
            $path = $request->file($file)->storeAs('public/profileimage', time().$imageName);
            $path=str_replace('public/','',$path);
        }
       return $path;
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $newavatar=$this->updateprofile($request,'avatar');

        unset($request['avatar']);

        request()->validate(ExerciseLibrary::$rules);
        $data=array_merge($request->all(),['created_by' => Auth::user()->id,'avatar' => $newavatar]);

        $exerciseLibrary = ExerciseLibrary::create($data);


       return "done";
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $exerciseLibrary = ExerciseLibrary::find($id);

        return view('n10pages.exercise-library.show', compact('exerciseLibrary'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $page_heading='Edit Library';
        $sub_page_heading='edit library';
        $exerciseLibrary = ExerciseLibrary::find($id);
        $formRoute=route('exercise-libraries.update',$id);
        $type='POST';
            $categories=ExerciseCategory::all();
        $equipments=ExerciseEquipment::all();
        $movement_patterns=ExerciseMovementPattern::all();
        return view('n10pages.exercise-library.edit', compact('exerciseLibrary','formRoute','type','categories','equipments','movement_patterns','page_heading','sub_page_heading'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ExerciseLibrary $exerciseLibrary
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExerciseLibrary $exerciseLibrary)
    {
        request()->validate(ExerciseLibrary::$rules);

        if($request->hasFile('avatar')){
            $newavatar=$this->updateprofile($request,'avatar');
            unset($request['avatar']);
            $exerciseLibrary->update(array_merge($request->all(),['avatar' => $newavatar]));
        }
        else{
            $exerciseLibrary->update(array_merge($request->all()));
        }

        return "done";
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $exerciseLibrary = ExerciseLibrary::find($id)->delete();

        return redirect()->route('exercise-libraries.index')
            ->with('success', 'ExerciseLibrary deleted successfully');
    }

    public function getInfo(Request $request)
    {
        $exerciseCategory = ExerciseLibrary::with('exerciseCategory','exerciseEquipment','exerciseMovementPattern')->where('id',$request->id)->get()->first();

        return $exerciseCategory;
    }

    function approveLibrary(Request $request){

        $exerciseLibrary = ExerciseLibrary::find($request->id)->update(['approved_by' => Auth::user()->id , 'rejected_by' => 0 ]);

        return redirect()->route('exercise-libraries-approved')
            ->with('success', 'ExerciseLibrary deleted successfully');
    }

    function rejectLibrary(Request $request){

        $exerciseLibrary = ExerciseLibrary::find($request->id)->update(['rejected_by' => Auth::user()->id , 'approved_by' => 0 ]);

        return redirect()->route('exercise-libraries-rejected')
            ->with('success', 'ExerciseLibrary deleted successfully');
    }
}
