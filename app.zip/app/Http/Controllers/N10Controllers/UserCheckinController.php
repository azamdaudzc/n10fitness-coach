<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\UserCheckin;
use Illuminate\Http\Request;
/**
 * Class UserCheckinController
 * @package App\Http\Controllers
 */
class UserCheckinController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $userCheckins = UserCheckin::paginate();

        // return view('n10pages.user-checkin.index', compact('userCheckins'))
        //     ->with('i', (request()->input('page', 1) - 1) * $userCheckins->perPage());
        $data['userCheckins'] = UserCheckin::all();
        return view('n10pages.user-checkin.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $userCheckin = new UserCheckin();
        return view('n10pages.user-checkin.create', compact('userCheckin'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(UserCheckin::$rules);

        $userCheckin = UserCheckin::create($request->all());

        return redirect()->route('user-checkins.index')
            ->with('success', 'UserCheckin created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $userCheckin = UserCheckin::find($id);

        return view('n10pages.user-checkin.show', compact('userCheckin'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $userCheckin = UserCheckin::find($id);

        return view('n10pages.user-checkin.edit', compact('userCheckin'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  UserCheckin $userCheckin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserCheckin $userCheckin)
    {
        request()->validate(UserCheckin::$rules);

        $userCheckin->update($request->all());

        return redirect()->route('user-checkins.index')
            ->with('success', 'UserCheckin updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $userCheckin = UserCheckin::find($id)->delete();

        return redirect()->route('user-checkins.index')
            ->with('success', 'UserCheckin deleted successfully');
    }
}
