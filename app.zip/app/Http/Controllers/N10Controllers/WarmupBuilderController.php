<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\WarmupBuilder;
use Illuminate\Http\Request;
/**
 * Class WarmupBuilderController
 * @package App\Http\Controllers
 */
class WarmupBuilderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $warmupBuilders = WarmupBuilder::paginate();

        // return view('n10pages.warmup-builder.index', compact('warmupBuilders'))
        //     ->with('i', (request()->input('page', 1) - 1) * $warmupBuilders->perPage());
        $data['warmupBuilders'] = WarmupBuilder::all();
        return view('n10pages.warmup-builder.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $warmupBuilder = new WarmupBuilder();
        return view('n10pages.warmup-builder.create', compact('warmupBuilder'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(WarmupBuilder::$rules);

        $warmupBuilder = WarmupBuilder::create($request->all());

        return redirect()->route('warmup-builders.index')
            ->with('success', 'WarmupBuilder created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $warmupBuilder = WarmupBuilder::find($id);

        return view('n10pages.warmup-builder.show', compact('warmupBuilder'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $warmupBuilder = WarmupBuilder::find($id);

        return view('n10pages.warmup-builder.edit', compact('warmupBuilder'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  WarmupBuilder $warmupBuilder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, WarmupBuilder $warmupBuilder)
    {
        request()->validate(WarmupBuilder::$rules);

        $warmupBuilder->update($request->all());

        return redirect()->route('warmup-builders.index')
            ->with('success', 'WarmupBuilder updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $warmupBuilder = WarmupBuilder::find($id)->delete();

        return redirect()->route('warmup-builders.index')
            ->with('success', 'WarmupBuilder deleted successfully');
    }
}
