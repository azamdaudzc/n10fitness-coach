<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderShare;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderShareController
 * @package App\Http\Controllers
 */
class ProgramBuilderShareController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderShares = ProgramBuilderShare::paginate();

        // return view('n10pages.program-builder-share.index', compact('programBuilderShares'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderShares->perPage());
        $data['programBuilderShares'] = ProgramBuilderShare::all();
        return view('n10pages.program-builder-share.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderShare = new ProgramBuilderShare();
        return view('n10pages.program-builder-share.create', compact('programBuilderShare'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderShare::$rules);

        $programBuilderShare = ProgramBuilderShare::create($request->all());

        return redirect()->route('program-builder-shares.index')
            ->with('success', 'ProgramBuilderShare created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderShare = ProgramBuilderShare::find($id);

        return view('n10pages.program-builder-share.show', compact('programBuilderShare'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderShare = ProgramBuilderShare::find($id);

        return view('n10pages.program-builder-share.edit', compact('programBuilderShare'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderShare $programBuilderShare
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderShare $programBuilderShare)
    {
        request()->validate(ProgramBuilderShare::$rules);

        $programBuilderShare->update($request->all());

        return redirect()->route('program-builder-shares.index')
            ->with('success', 'ProgramBuilderShare updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderShare = ProgramBuilderShare::find($id)->delete();

        return redirect()->route('program-builder-shares.index')
            ->with('success', 'ProgramBuilderShare deleted successfully');
    }
}
