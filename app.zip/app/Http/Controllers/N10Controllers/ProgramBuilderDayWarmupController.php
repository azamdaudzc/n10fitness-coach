<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderDayWarmup;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderDayWarmupController
 * @package App\Http\Controllers
 */
class ProgramBuilderDayWarmupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderDayWarmups = ProgramBuilderDayWarmup::paginate();

        // return view('n10pages.program-builder-day-warmup.index', compact('programBuilderDayWarmups'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderDayWarmups->perPage());
        $data['builderDayWarmups'] = ProgramBuilderDayWarmup::all();
        return view('n10pages.program-builder-day-warmup.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderDayWarmup = new ProgramBuilderDayWarmup();
        return view('n10pages.program-builder-day-warmup.create', compact('programBuilderDayWarmup'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderDayWarmup::$rules);

        $programBuilderDayWarmup = ProgramBuilderDayWarmup::create($request->all());

        return redirect()->route('builder-day-warmups.index')
            ->with('success', 'ProgramBuilderDayWarmup created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderDayWarmup = ProgramBuilderDayWarmup::find($id);

        return view('n10pages.program-builder-day-warmup.show', compact('programBuilderDayWarmup'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderDayWarmup = ProgramBuilderDayWarmup::find($id);

        return view('n10pages.program-builder-day-warmup.edit', compact('programBuilderDayWarmup'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderDayWarmup $programBuilderDayWarmup
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderDayWarmup $programBuilderDayWarmup)
    {
        request()->validate(ProgramBuilderDayWarmup::$rules);

        $programBuilderDayWarmup->update($request->all());

        return redirect()->route('builder-day-warmups.index')
            ->with('success', 'ProgramBuilderDayWarmup updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderDayWarmup = ProgramBuilderDayWarmup::find($id)->delete();

        return redirect()->route('builder-day-warmups.index')
            ->with('success', 'ProgramBuilderDayWarmup deleted successfully');
    }
}
