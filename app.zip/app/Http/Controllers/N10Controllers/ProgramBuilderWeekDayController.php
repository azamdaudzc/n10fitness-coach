<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderWeekDay;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderWeekDayController
 * @package App\Http\Controllers
 */
class ProgramBuilderWeekDayController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderWeekDays = ProgramBuilderWeekDay::paginate();

        // return view('n10pages.program-builder-week-day.index', compact('programBuilderWeekDays'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderWeekDays->perPage());
        $data['programBuilderWeekDays'] = ProgramBuilderWeekDay::all();
        return view('n10pages.program-builder-week-day.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderWeekDay = new ProgramBuilderWeekDay();
        return view('n10pages.program-builder-week-day.create', compact('programBuilderWeekDay'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderWeekDay::$rules);

        $programBuilderWeekDay = ProgramBuilderWeekDay::create($request->all());

        return redirect()->route('program-builder-week-days.index')
            ->with('success', 'ProgramBuilderWeekDay created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderWeekDay = ProgramBuilderWeekDay::find($id);

        return view('n10pages.program-builder-week-day.show', compact('programBuilderWeekDay'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderWeekDay = ProgramBuilderWeekDay::find($id);

        return view('n10pages.program-builder-week-day.edit', compact('programBuilderWeekDay'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderWeekDay $programBuilderWeekDay
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderWeekDay $programBuilderWeekDay)
    {
        request()->validate(ProgramBuilderWeekDay::$rules);

        $programBuilderWeekDay->update($request->all());

        return redirect()->route('program-builder-week-days.index')
            ->with('success', 'ProgramBuilderWeekDay updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderWeekDay = ProgramBuilderWeekDay::find($id)->delete();

        return redirect()->route('program-builder-week-days.index')
            ->with('success', 'ProgramBuilderWeekDay deleted successfully');
    }
}
