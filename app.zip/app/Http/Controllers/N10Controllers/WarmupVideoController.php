<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\WarmupVideo;
use Illuminate\Http\Request;
/**
 * Class WarmupVideoController
 * @package App\Http\Controllers
 */
class WarmupVideoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $warmupVideos = WarmupVideo::paginate();

        // return view('n10pages.warmup-video.index', compact('warmupVideos'))
        //     ->with('i', (request()->input('page', 1) - 1) * $warmupVideos->perPage());
        $data['warmupVideos'] = WarmupVideo::all();
    return view('n10pages.warmup-video.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $warmupVideo = new WarmupVideo();
        return view('n10pages.warmup-video.create', compact('warmupVideo'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(WarmupVideo::$rules);

        $warmupVideo = WarmupVideo::create($request->all());

        return redirect()->route('warmup-videos.index')
            ->with('success', 'WarmupVideo created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $warmupVideo = WarmupVideo::find($id);

        return view('n10pages.warmup-video.show', compact('warmupVideo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $warmupVideo = WarmupVideo::find($id);

        return view('n10pages.warmup-video.edit', compact('warmupVideo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  WarmupVideo $warmupVideo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, WarmupVideo $warmupVideo)
    {
        request()->validate(WarmupVideo::$rules);

        $warmupVideo->update($request->all());

        return redirect()->route('warmup-videos.index')
            ->with('success', 'WarmupVideo updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $warmupVideo = WarmupVideo::find($id)->delete();

        return redirect()->route('warmup-videos.index')
            ->with('success', 'WarmupVideo deleted successfully');
    }
}
