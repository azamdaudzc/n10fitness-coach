<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\CheckinQuestionInput;
use Illuminate\Http\Request;

/**
 * Class CheckinQuestionInputController
 * @package App\Http\Controllers
 */
class CheckinQuestionInputController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $checkinQuestionInputs = CheckinQuestionInput::paginate();

        // return view('n10pages.checkin-question-input.index', compact('checkinQuestionInputs'))
        //     ->with('i', (request()->input('page', 1) - 1) * $checkinQuestionInputs->perPage());
        $data['checkinQuestionInput'] = CheckinQuestionInput::all();
        return view('n10pages.checkin-question-input.index')->with($data);

    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $checkinQuestionInput = new CheckinQuestionInput();
        return view('n10pages.checkin-question-input.create', compact('checkinQuestionInput'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(CheckinQuestionInput::$rules);

        $checkinQuestionInput = CheckinQuestionInput::create($request->all());

        return redirect()->route('checkin-question-inputs.index')
            ->with('success', 'CheckinQuestionInput created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $checkinQuestionInput = CheckinQuestionInput::find($id);

        return view('n10pages.checkin-question-input.show', compact('checkinQuestionInput'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $checkinQuestionInput = CheckinQuestionInput::find($id);

        return view('n10pages.checkin-question-input.edit', compact('checkinQuestionInput'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  CheckinQuestionInput $checkinQuestionInput
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CheckinQuestionInput $checkinQuestionInput)
    {
        request()->validate(CheckinQuestionInput::$rules);

        $checkinQuestionInput->update($request->all());

        return redirect()->route('checkin-question-inputs.index')
            ->with('success', 'CheckinQuestionInput updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $checkinQuestionInput = CheckinQuestionInput::find($id)->delete();

        return redirect()->route('checkin-question-inputs.index')
            ->with('success', 'CheckinQuestionInput deleted successfully');
    }
}
