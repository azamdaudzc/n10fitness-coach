<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderDayExercise;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderDayExerciseController
 * @package App\Http\Controllers
 */
class ProgramBuilderDayExerciseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderDayExercises = ProgramBuilderDayExercise::paginate();

        // return view('n10pages.program-builder-day-exercise.index', compact('programBuilderDayExercises'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderDayExercises->perPage());
        $data['programBuilderDayExercises'] = ProgramBuilderDayExercise::all();
        return view('n10pages.program-builder-day-exercise.index')->with($data);

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderDayExercise = new ProgramBuilderDayExercise();
        return view('n10pages.program-builder-day-exercise.create', compact('programBuilderDayExercise'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderDayExercise::$rules);

        $programBuilderDayExercise = ProgramBuilderDayExercise::create($request->all());

        return redirect()->route('program-builders-day-exercises.index')
            ->with('success', 'ProgramBuilderDayExercise created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderDayExercise = ProgramBuilderDayExercise::find($id);

        return view('n10pages.program-builder-day-exercise.show', compact('programBuilderDayExercise'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderDayExercise = ProgramBuilderDayExercise::find($id);

        return view('n10pages.program-builder-day-exercise.edit', compact('programBuilderDayExercise'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderDayExercise $programBuilderDayExercise
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderDayExercise $programBuilderDayExercise)
    {
        request()->validate(ProgramBuilderDayExercise::$rules);

        $programBuilderDayExercise->update($request->all());

        return redirect()->route('program-builders-day-exercises.index')
            ->with('success', 'ProgramBuilderDayExercise updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderDayExercise = ProgramBuilderDayExercise::find($id)->delete();

        return redirect()->route('program-builders-day-exercises.index')
            ->with('success', 'ProgramBuilderDayExercise deleted successfully');
    }
}
