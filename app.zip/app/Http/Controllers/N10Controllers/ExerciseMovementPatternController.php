<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ExerciseMovementPattern;
use Illuminate\Http\Request;
use App\DataTables\ExerciseMovementPatternDataTable;
/**
 * Class ExerciseMovementPatternController
 * @package App\Http\Controllers
 */
class ExerciseMovementPatternController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $exerciseMovementPatterns = ExerciseMovementPattern::paginate();

        // return view('n10pages.exercise-movement-pattern.index', compact('exerciseMovementPatterns'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseMovementPatterns->perPage());
        $data['exerciseMovementPatterns'] = ExerciseMovementPattern::all();
        $data['exerciseMovementPattern'] = new ExerciseMovementPattern();

        return view('n10pages.exercise-movement-pattern.index')->with($data);

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $exerciseMovementPattern = new ExerciseMovementPattern();
        return view('n10pages.exercise-movement-pattern.create', compact('exerciseMovementPattern'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ExerciseMovementPattern::$rules);

        $exerciseMovementPattern = ExerciseMovementPattern::create($request->all());

        return redirect()->route('exercise-movement-patterns.index')
            ->with('success', 'ExerciseMovementPattern created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $exerciseMovementPattern = ExerciseMovementPattern::find($id);

        return view('n10pages.exercise-movement-pattern.show', compact('exerciseMovementPattern'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $exerciseMovementPattern = ExerciseMovementPattern::find($id);

        return view('n10pages.exercise-movement-pattern.edit', compact('exerciseMovementPattern'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ExerciseMovementPattern $exerciseMovementPattern
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExerciseMovementPattern $exerciseMovementPattern)
    {
        request()->validate(ExerciseMovementPattern::$rules);

        $exerciseMovementPattern->update($request->all());

        return redirect()->route('exercise-movement-patterns.index')
            ->with('success', 'ExerciseMovementPattern updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $exerciseMovementPattern = ExerciseMovementPattern::find($id)->delete();

        return redirect()->route('exercise-movement-patterns.index')
            ->with('success', 'ExerciseMovementPattern deleted successfully');
    }
}
