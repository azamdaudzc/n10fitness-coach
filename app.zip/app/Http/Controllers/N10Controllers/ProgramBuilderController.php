<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilder;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderController
 * @package App\Http\Controllers
 */
class ProgramBuilderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilders = ProgramBuilder::paginate();

        // return view('n10pages.program-builder.index', compact('programBuilders'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilders->perPage());
        $data['programBuilders'] = ProgramBuilder::all();
        return view('n10pages.program-builder.index')->with($data);

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilder = new ProgramBuilder();
        return view('n10pages.program-builder.create', compact('programBuilder'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilder::$rules);

        $programBuilder = ProgramBuilder::create($request->all());

        return redirect()->route('program-builders.index')
            ->with('success', 'ProgramBuilder created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilder = ProgramBuilder::find($id);

        return view('n10pages.program-builder.show', compact('programBuilder'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilder = ProgramBuilder::find($id);

        return view('n10pages.program-builder.edit', compact('programBuilder'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilder $programBuilder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilder $programBuilder)
    {
        request()->validate(ProgramBuilder::$rules);

        $programBuilder->update($request->all());

        return redirect()->route('program-builders.index')
            ->with('success', 'ProgramBuilder updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilder = ProgramBuilder::find($id)->delete();

        return redirect()->route('program-builders.index')
            ->with('success', 'ProgramBuilder deleted successfully');
    }
}
