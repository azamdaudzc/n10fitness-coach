<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\UserCheckinAnswer;
use Illuminate\Http\Request;
/**
 * Class UserCheckinAnswerController
 * @package App\Http\Controllers
 */
class UserCheckinAnswerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $userCheckinAnswers = UserCheckinAnswer::paginate();

        // return view('n10pages.user-checkin-answer.index', compact('userCheckinAnswers'))
        //     ->with('i', (request()->input('page', 1) - 1) * $userCheckinAnswers->perPage());
        $data['userCheckinAnswers'] = UserCheckinAnswer::all();
        return view('n10pages.user-checkin-answer.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $userCheckinAnswer = new UserCheckinAnswer();
        return view('n10pages.user-checkin-answer.create', compact('userCheckinAnswer'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(UserCheckinAnswer::$rules);

        $userCheckinAnswer = UserCheckinAnswer::create($request->all());

        return redirect()->route('user-checkin-answers.index')
            ->with('success', 'UserCheckinAnswer created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $userCheckinAnswer = UserCheckinAnswer::find($id);

        return view('n10pages.user-checkin-answer.show', compact('userCheckinAnswer'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $userCheckinAnswer = UserCheckinAnswer::find($id);

        return view('n10pages.user-checkin-answer.edit', compact('userCheckinAnswer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  UserCheckinAnswer $userCheckinAnswer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserCheckinAnswer $userCheckinAnswer)
    {
        request()->validate(UserCheckinAnswer::$rules);

        $userCheckinAnswer->update($request->all());

        return redirect()->route('user-checkin-answers.index')
            ->with('success', 'UserCheckinAnswer updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $userCheckinAnswer = UserCheckinAnswer::find($id)->delete();

        return redirect()->route('user-checkin-answers.index')
            ->with('success', 'UserCheckinAnswer deleted successfully');
    }
}
