<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\AthleticType;
use Illuminate\Http\Request;

/**
 * Class AthleticTypeController
 * @package App\Http\Controllers
 */
class AthleticTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['athleticTypes'] = AthleticType::all();
        return view('n10pages.athletic-type.index')->with($data);
        // return view('n10pages.athletic-type.index', compact('athleticTypes'))
        //     ->with('i', (request()->input('page', 1) - 1) * $athleticTypes->perPage());
    }

    //NOT USED
    public function viewAthleticTypes(){
        $data['getDataRoute']=route('getAthleticTypes');
        return view('n10pages.athletic-type.index-datatable')->with($data);
    }
    //NOT USED
    public function getAthleticTypesForLater()
    {
        return AthleticType::all();
    }
    //NOT USED
    public function getAthleticTypes(Request $request)
    {
        $draw = $request->get('draw');
        $start = $request->get("start");
        $rowperpage = $request->get("length"); // Rows display per page

        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');

        $columnIndex = $columnIndex_arr[0]['column']; // Column index
        $columnName = $columnName_arr[$columnIndex]['data']; // Column name
        $columnSortOrder = $order_arr[0]['dir']; // asc or desc
        $searchValue = $search_arr['value']; // Search value

        // Total records
        $totalRecords = AthleticType::select('count(*) as allcount')->count();
        $totalRecordswithFilter = AthleticType::select('count(*) as allcount')->where('name', 'like', '%' .$searchValue . '%')->count();

        // Fetch records
        $records = AthleticType::orderBy($columnName,$columnSortOrder)
            ->where('athletic_types.name', 'like', '%' .$searchValue . '%')
            ->select('athletic_types.*')
            ->skip($start)
            ->take($rowperpage)
            ->get();

        $data_arr = array();
        $sno = $start+1;
        foreach($records as $record){
            $id = $record->id;
            $name = $record->name;
            $date_created = $record->created_at;

            $data_arr[] = array(
                "id" => $id,
                "name" => $name,
                "created_at" => $date_created
            );
        }

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr
        );

        echo json_encode($response);
        exit;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $athleticType = new AthleticType();
        return view('n10pages.athletic-type.create', compact('athleticType'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(AthleticType::$rules);

        $athleticType = AthleticType::create($request->all());

        return redirect()->route('athletic-types.index')
            ->with('success', 'AthleticType created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $athleticType = AthleticType::find($id);

        return view('n10pages.athletic-type.show', compact('athleticType'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $athleticType = AthleticType::find($id);

        return view('n10pages.athletic-type.edit', compact('athleticType'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  AthleticType $athleticType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AthleticType $athleticType)
    {
        request()->validate(AthleticType::$rules);

        $athleticType->update($request->all());

        return redirect()->route('athletic-types.index')
            ->with('success', 'AthleticType updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $athleticType = AthleticType::find($id)->delete();

        return redirect()->route('athletic-types.index')
            ->with('success', 'AthleticType deleted successfully');
    }
}
