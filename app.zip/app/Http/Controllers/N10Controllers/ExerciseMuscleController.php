<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ExerciseMuscle;
use Illuminate\Http\Request;

/**
 * Class ExerciseMuscleController
 * @package App\Http\Controllers
 */
class ExerciseMuscleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $exerciseMuscles = ExerciseMuscle::paginate();

        // return view('n10pages.exercise-muscle.index', compact('exerciseMuscles'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseMuscles->perPage());
        $data['exerciseMuscles'] = ExerciseMuscle::all();
        $data['exerciseMuscle'] = new ExerciseMuscle();

        return view('n10pages.exercise-muscle.index')->with($data);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $exerciseMuscle = new ExerciseMuscle();
        return view('n10pages.exercise-muscle.create', compact('exerciseMuscle'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ExerciseMuscle::$rules);

        $exerciseMuscle = ExerciseMuscle::create($request->all());

        return redirect()->route('exercise-muscles.index')
            ->with('success', 'ExerciseMuscle created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $exerciseMuscle = ExerciseMuscle::find($id);

        return view('n10pages.exercise-muscle.show', compact('exerciseMuscle'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $exerciseMuscle = ExerciseMuscle::find($id);

        return view('n10pages.exercise-muscle.edit', compact('exerciseMuscle'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ExerciseMuscle $exerciseMuscle
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExerciseMuscle $exerciseMuscle)
    {
        request()->validate(ExerciseMuscle::$rules);

        $exerciseMuscle->update($request->all());

        return redirect()->route('exercise-muscles.index')
            ->with('success', 'ExerciseMuscle updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $exerciseMuscle = ExerciseMuscle::find($id)->delete();

        return redirect()->route('exercise-muscles.index')
            ->with('success', 'ExerciseMuscle deleted successfully');
    }
}
