<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderTemplate;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderTemplateController
 * @package App\Http\Controllers
 */
class ProgramBuilderTemplateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderTemplates = ProgramBuilderTemplate::paginate();

        // return view('n10pages.program-builder-template.index', compact('programBuilderTemplates'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderTemplates->perPage());
        $data['programBuilderTemplates'] = ProgramBuilderTemplate::all();
        return view('n10pages.program-builder-template.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderTemplate = new ProgramBuilderTemplate();
        return view('n10pages.program-builder-template.create', compact('programBuilderTemplate'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderTemplate::$rules);

        $programBuilderTemplate = ProgramBuilderTemplate::create($request->all());

        return redirect()->route('program-builder-templates.index')
            ->with('success', 'ProgramBuilderTemplate created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderTemplate = ProgramBuilderTemplate::find($id);

        return view('n10pages.program-builder-template.show', compact('programBuilderTemplate'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderTemplate = ProgramBuilderTemplate::find($id);

        return view('n10pages.program-builder-template.edit', compact('programBuilderTemplate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderTemplate $programBuilderTemplate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderTemplate $programBuilderTemplate)
    {
        request()->validate(ProgramBuilderTemplate::$rules);

        $programBuilderTemplate->update($request->all());

        return redirect()->route('program-builder-templates.index')
            ->with('success', 'ProgramBuilderTemplate updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderTemplate = ProgramBuilderTemplate::find($id)->delete();

        return redirect()->route('program-builder-templates.index')
            ->with('success', 'ProgramBuilderTemplate deleted successfully');
    }
}
