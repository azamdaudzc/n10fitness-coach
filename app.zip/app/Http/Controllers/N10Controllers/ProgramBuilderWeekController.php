<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderWeek;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderWeekController
 * @package App\Http\Controllers
 */
class ProgramBuilderWeekController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderWeeks = ProgramBuilderWeek::paginate();

        // return view('n10pages.program-builder-week.index', compact('programBuilderWeeks'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderWeeks->perPage());
        $data['programBuilderWeeks'] = ProgramBuilderWeek::all();
        return view('n10pages.program-builder-week.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderWeek = new ProgramBuilderWeek();
        return view('n10pages.program-builder-week.create', compact('programBuilderWeek'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderWeek::$rules);

        $programBuilderWeek = ProgramBuilderWeek::create($request->all());

        return redirect()->route('program-builder-weeks.index')
            ->with('success', 'ProgramBuilderWeek created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderWeek = ProgramBuilderWeek::find($id);

        return view('n10pages.program-builder-week.show', compact('programBuilderWeek'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderWeek = ProgramBuilderWeek::find($id);

        return view('n10pages.program-builder-week.edit', compact('programBuilderWeek'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderWeek $programBuilderWeek
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderWeek $programBuilderWeek)
    {
        request()->validate(ProgramBuilderWeek::$rules);

        $programBuilderWeek->update($request->all());

        return redirect()->route('program-builder-weeks.index')
            ->with('success', 'ProgramBuilderWeek updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderWeek = ProgramBuilderWeek::find($id)->delete();

        return redirect()->route('program-builder-weeks.index')
            ->with('success', 'ProgramBuilderWeek deleted successfully');
    }
}
