<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\CheckinQuestion;
use Illuminate\Http\Request;

/**
 * Class CheckinQuestionController
 * @package App\Http\Controllers
 */
class CheckinQuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      //  $checkinQuestions = CheckinQuestion::paginate();

    //     return view('n10pages.checkin-question.index', compact('checkinQuestions'))
    //         ->with('i', (request()->input('page', 1) - 1) * $checkinQuestions->perPage());
    $data['checkinQuestions'] = CheckinQuestion::all();
    return view('n10pages.checkin-question.index')->with($data);

}



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $checkinQuestion = new CheckinQuestion();
        return view('n10pages.checkin-question.create', compact('checkinQuestion'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(CheckinQuestion::$rules);

        $checkinQuestion = CheckinQuestion::create($request->all());

        return redirect()->route('checkin-questions.index')
            ->with('success', 'CheckinQuestion created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $checkinQuestion = CheckinQuestion::find($id);

        return view('n10pages.checkin-question.show', compact('checkinQuestion'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $checkinQuestion = CheckinQuestion::find($id);

        return view('n10pages.checkin-question.edit', compact('checkinQuestion'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  CheckinQuestion $checkinQuestion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CheckinQuestion $checkinQuestion)
    {
        request()->validate(CheckinQuestion::$rules);

        $checkinQuestion->update($request->all());

        return redirect()->route('checkin-questions.index')
            ->with('success', 'CheckinQuestion updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $checkinQuestion = CheckinQuestion::find($id)->delete();

        return redirect()->route('checkin-questions.index')
            ->with('success', 'CheckinQuestion deleted successfully');
    }
}
