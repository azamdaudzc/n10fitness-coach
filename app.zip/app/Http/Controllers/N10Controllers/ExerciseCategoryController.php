<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ExerciseCategory;
use Illuminate\Http\Request;

/**
 * Class ExerciseCategoryController
 * @package App\Http\Controllers
 */
class ExerciseCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $exerciseCategories = ExerciseCategory::paginate();

        // return view('n10pages.exercise-category.index', compact('exerciseCategories'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseCategories->perPage());
        $data['exerciseCategories'] = ExerciseCategory::all();
        $data['exerciseCategory'] = new ExerciseCategory();
        return view('n10pages.exercise-category.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $exerciseCategory = new ExerciseCategory();
        return view('n10pages.exercise-category.create', compact('exerciseCategory'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ExerciseCategory::$rules);

        $exerciseCategory = ExerciseCategory::create($request->all());

        return redirect()->route('exercise-categories.index')
            ->with('success', 'ExerciseCategory created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $exerciseCategory = ExerciseCategory::find($id);

        return view('n10pages.exercise-category.show', compact('exerciseCategory'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $exerciseCategory = ExerciseCategory::find($id);

        return view('n10pages.exercise-category.edit', compact('exerciseCategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ExerciseCategory $exerciseCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExerciseCategory $exerciseCategory)
    {
        request()->validate(ExerciseCategory::$rules);

        $exerciseCategory->update($request->all());

        return redirect()->route('exercise-categories.index')
            ->with('success', 'ExerciseCategory updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $exerciseCategory = ExerciseCategory::find($id)->delete();

        return redirect()->route('exercise-categories.index')
            ->with('success', 'ExerciseCategory deleted successfully');
    }
}
