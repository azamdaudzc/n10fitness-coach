<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ExcerciseLibraryMuscle;
use Illuminate\Http\Request;

/**
 * Class ExcerciseLibraryMuscleController
 * @package App\Http\Controllers
 */
class ExcerciseLibraryMuscleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $excerciseLibraryMuscles = ExcerciseLibraryMuscle::paginate();

        // return view('n10pages.excercise-library-muscle.index', compact('excerciseLibraryMuscles'))
        //     ->with('i', (request()->input('page', 1) - 1) * $excerciseLibraryMuscles->perPage());
        $data['excerciseLibraryMuscles'] = ExcerciseLibraryMuscle::all();
        $data['excerciseLibraryMuscle'] = new ExcerciseLibraryMuscle();
    return view('n10pages.excercise-library-muscle.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $excerciseLibraryMuscle = new ExcerciseLibraryMuscle();
        return view('n10pages.excercise-library-muscle.create', compact('excerciseLibraryMuscle'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ExcerciseLibraryMuscle::$rules);

        $excerciseLibraryMuscle = ExcerciseLibraryMuscle::create($request->all());

        return redirect()->route('excercise-library-muscles.index')
            ->with('success', 'ExcerciseLibraryMuscle created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $excerciseLibraryMuscle = ExcerciseLibraryMuscle::find($id);

        return view('n10pages.excercise-library-muscle.show', compact('excerciseLibraryMuscle'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $excerciseLibraryMuscle = ExcerciseLibraryMuscle::find($id);

        return view('n10pages.excercise-library-muscle.edit', compact('excerciseLibraryMuscle'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ExcerciseLibraryMuscle $excerciseLibraryMuscle
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExcerciseLibraryMuscle $excerciseLibraryMuscle)
    {
        request()->validate(ExcerciseLibraryMuscle::$rules);

        $excerciseLibraryMuscle->update($request->all());

        return redirect()->route('excercise-library-muscles.index')
            ->with('success', 'ExcerciseLibraryMuscle updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $excerciseLibraryMuscle = ExcerciseLibraryMuscle::find($id)->delete();

        return redirect()->route('excercise-library-muscles.index')
            ->with('success', 'ExcerciseLibraryMuscle deleted successfully');
    }
}
