<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ClientCoach;
use Illuminate\Http\Request;
use App\DataTables\ClientCoachDataTable;
/**
 * Class ClientCoachController
 * @package App\Http\Controllers
 */
class ClientCoachController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $clientCoaches = ClientCoach::paginate();

        // return view('n10pages.client-coach.index', compact('clientCoaches'))
        //     ->with('i', (request()->input('page', 1) - 1) * $clientCoaches->perPage());
        $data['clientCoaches'] = ClientCoach::all();
    return view('n10pages.client-coach.index')->with($data);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $clientCoach = new ClientCoach();
        return view('n10pages.client-coach.create', compact('clientCoach'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ClientCoach::$rules);

        $clientCoach = ClientCoach::create($request->all());

        return redirect()->route('client-coaches.index')
            ->with('success', 'ClientCoach created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $clientCoach = ClientCoach::find($id);

        return view('n10pages.client-coach.show', compact('clientCoach'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $clientCoach = ClientCoach::find($id);

        return view('n10pages.client-coach.edit', compact('clientCoach'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ClientCoach $clientCoach
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ClientCoach $clientCoach)
    {
        request()->validate(ClientCoach::$rules);

        $clientCoach->update($request->all());

        return redirect()->route('client-coaches.index')
            ->with('success', 'ClientCoach updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $clientCoach = ClientCoach::find($id)->delete();

        return redirect()->route('client-coaches.index')
            ->with('success', 'ClientCoach deleted successfully');
    }
}
