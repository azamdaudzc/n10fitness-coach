<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ExerciseEquipment;
use Illuminate\Http\Request;
/**
 * Class ExerciseEquipmentController
 * @package App\Http\Controllers
 */
class ExerciseEquipmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $exerciseEquipments = ExerciseEquipment::paginate();

        // return view('n10pages.exercise-equipment.index', compact('exerciseEquipments'))
        //     ->with('i', (request()->input('page', 1) - 1) * $exerciseEquipments->perPage());
        $data['exerciseEquipments'] = ExerciseEquipment::all();
        $data['exerciseEquipment'] = new ExerciseEquipment();
        return view('n10pages.exercise-equipment.index')->with($data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $exerciseEquipment = new ExerciseEquipment();
        return view('n10pages.exercise-equipment.create', compact('exerciseEquipment'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ExerciseEquipment::$rules);

        $exerciseEquipment = ExerciseEquipment::create($request->all());

        return redirect()->route('exercise-equipments.index')
            ->with('success', 'ExerciseEquipment created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $exerciseEquipment = ExerciseEquipment::find($id);

        return view('n10pages.exercise-equipment.show', compact('exerciseEquipment'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $exerciseEquipment = ExerciseEquipment::find($id);

        return view('n10pages.exercise-equipment.edit', compact('exerciseEquipment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ExerciseEquipment $exerciseEquipment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExerciseEquipment $exerciseEquipment)
    {
        request()->validate(ExerciseEquipment::$rules);

        $exerciseEquipment->update($request->all());

        return redirect()->route('exercise-equipments.index')
            ->with('success', 'ExerciseEquipment updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $exerciseEquipment = ExerciseEquipment::find($id)->delete();

        return redirect()->route('exercise-equipments.index')
            ->with('success', 'ExerciseEquipment deleted successfully');
    }
}
