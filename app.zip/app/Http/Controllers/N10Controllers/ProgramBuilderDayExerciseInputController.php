<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\ProgramBuilderDayExerciseInput;
use Illuminate\Http\Request;
/**
 * Class ProgramBuilderDayExerciseInputController
 * @package App\Http\Controllers
 */
class ProgramBuilderDayExerciseInputController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $programBuilderDayExerciseInputs = ProgramBuilderDayExerciseInput::paginate();

        // return view('n10pages.program-builder-day-exercise-input.index', compact('programBuilderDayExerciseInputs'))
        //     ->with('i', (request()->input('page', 1) - 1) * $programBuilderDayExerciseInputs->perPage());
        $data['builderDayExerciseInputs'] = ProgramBuilderDayExerciseInput::all();
        return view('n10pages.program-builder-day-exercise-input.index')->with($data);

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programBuilderDayExerciseInput = new ProgramBuilderDayExerciseInput();
        return view('n10pages.program-builder-day-exercise-input.create', compact('programBuilderDayExerciseInput'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProgramBuilderDayExerciseInput::$rules);

        $programBuilderDayExerciseInput = ProgramBuilderDayExerciseInput::create($request->all());

        return redirect()->route('builder-day-exercise-inputs.index')
            ->with('success', 'ProgramBuilderDayExerciseInput created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $programBuilderDayExerciseInput = ProgramBuilderDayExerciseInput::find($id);

        return view('n10pages.program-builder-day-exercise-input.show', compact('programBuilderDayExerciseInput'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $programBuilderDayExerciseInput = ProgramBuilderDayExerciseInput::find($id);

        return view('n10pages.program-builder-day-exercise-input.edit', compact('programBuilderDayExerciseInput'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProgramBuilderDayExerciseInput $programBuilderDayExerciseInput
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramBuilderDayExerciseInput $programBuilderDayExerciseInput)
    {
        request()->validate(ProgramBuilderDayExerciseInput::$rules);

        $programBuilderDayExerciseInput->update($request->all());

        return redirect()->route('builder-day-exercise-inputs.index')
            ->with('success', 'ProgramBuilderDayExerciseInput updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $programBuilderDayExerciseInput = ProgramBuilderDayExerciseInput::find($id)->delete();

        return redirect()->route('builder-day-exercise-inputs.index')
            ->with('success', 'ProgramBuilderDayExerciseInput deleted successfully');
    }
}
