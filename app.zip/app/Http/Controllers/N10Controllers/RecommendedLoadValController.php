<?php

namespace App\Http\Controllers\N10Controllers;

use App\Models\RecommendedLoadVal;
use Illuminate\Http\Request;
/**
 * Class RecommendedLoadValController
 * @package App\Http\Controllers
 */
class RecommendedLoadValController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $recommendedLoadVals = RecommendedLoadVal::paginate();

        // return view('n10pages.recommended-load-val.index', compact('recommendedLoadVals'))
        //     ->with('i', (request()->input('page', 1) - 1) * $recommendedLoadVals->perPage());
        $data['recommendedLoadVals'] = RecommendedLoadVal::all();
    return view('n10pages.recommended-load-val.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $recommendedLoadVal = new RecommendedLoadVal();
        return view('n10pages.recommended-load-val.create', compact('recommendedLoadVal'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(RecommendedLoadVal::$rules);

        $recommendedLoadVal = RecommendedLoadVal::create($request->all());

        return redirect()->route('recommended-load-vals.index')
            ->with('success', 'RecommendedLoadVal created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $recommendedLoadVal = RecommendedLoadVal::find($id);

        return view('n10pages.recommended-load-val.show', compact('recommendedLoadVal'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $recommendedLoadVal = RecommendedLoadVal::find($id);

        return view('n10pages.recommended-load-val.edit', compact('recommendedLoadVal'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  RecommendedLoadVal $recommendedLoadVal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RecommendedLoadVal $recommendedLoadVal)
    {
        request()->validate(RecommendedLoadVal::$rules);

        $recommendedLoadVal->update($request->all());

        return redirect()->route('recommended-load-vals.index')
            ->with('success', 'RecommendedLoadVal updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $recommendedLoadVal = RecommendedLoadVal::find($id)->delete();

        return redirect()->route('recommended-load-vals.index')
            ->with('success', 'RecommendedLoadVal deleted successfully');
    }
}
